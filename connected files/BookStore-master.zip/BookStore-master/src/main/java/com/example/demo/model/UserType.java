package com.example.demo.model;

public enum UserType {
    ADMIN, USER, EDITOR
}
