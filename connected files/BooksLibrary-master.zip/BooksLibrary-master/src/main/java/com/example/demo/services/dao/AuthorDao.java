package com.example.demo.services.dao;

import com.example.demo.model.AuthorEntity;

//here we will write specific behavior of Author
public interface AuthorDao extends GeneralDao<AuthorEntity>{


}
