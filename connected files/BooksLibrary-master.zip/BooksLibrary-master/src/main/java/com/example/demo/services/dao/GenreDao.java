package com.example.demo.services.dao;

import com.example.demo.model.GenreEntity;

//here we will write specific behavior of Genre
public interface GenreDao extends GeneralDao<GenreEntity> {

}
