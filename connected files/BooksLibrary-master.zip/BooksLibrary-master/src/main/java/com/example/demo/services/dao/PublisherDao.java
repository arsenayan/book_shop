package com.example.demo.services.dao;

import com.example.demo.model.PublisherEntity;

//here we will write specific behavior of Publisher
public interface PublisherDao extends GeneralDao<PublisherEntity> {


}
